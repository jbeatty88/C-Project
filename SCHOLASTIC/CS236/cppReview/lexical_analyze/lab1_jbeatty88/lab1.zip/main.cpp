
#include <iostream>
#include "Lexer.h"
using namespace std;

int main(int argc, char** argv) {
    Lexer lex(argv[1]);

    

    return 0;
}